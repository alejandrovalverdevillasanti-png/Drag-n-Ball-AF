package com.legacyofthesaiyans;

import com.legacyofthesaiyans.config.LegacyConfig;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(LegacyOfTheSaiyans.MOD_ID)
public class LegacyOfTheSaiyans {
    public static final String MOD_ID = "legacyofthesaiyans";

    public LegacyOfTheSaiyans() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, LegacyConfig.SPEC);
    }
}
