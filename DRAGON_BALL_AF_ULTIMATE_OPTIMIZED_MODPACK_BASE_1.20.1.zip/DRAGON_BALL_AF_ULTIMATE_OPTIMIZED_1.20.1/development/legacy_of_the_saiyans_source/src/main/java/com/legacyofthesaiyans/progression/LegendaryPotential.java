package com.legacyofthesaiyans.progression;
import net.minecraft.server.level.ServerPlayer;

/** Broly-inspired potential trait; selection/roll UI is not yet connected. */
public final class LegendaryPotential {
    public static final String NONE = "none";
    public static final String LEGENDARY_SAIYAN = "legendary_saiyan";
    private LegendaryPotential() {}
    public static String get(ServerPlayer player) {
        String id = player.getPersistentData().getString(ProgressionKeys.POTENTIAL);
        return id.isBlank() ? NONE : id;
    }
    public static boolean hasLegendaryPotential(ServerPlayer player) {
        return LEGENDARY_SAIYAN.equals(get(player));
    }
    public static void set(ServerPlayer player, String id) {
        player.getPersistentData().putString(ProgressionKeys.POTENTIAL,
                id == null || id.isBlank() ? NONE : id);
    }
    public static double growthMultiplier(ServerPlayer player) {
        return hasLegendaryPotential(player) ? 1.75D : 1.0D;
    }
}
