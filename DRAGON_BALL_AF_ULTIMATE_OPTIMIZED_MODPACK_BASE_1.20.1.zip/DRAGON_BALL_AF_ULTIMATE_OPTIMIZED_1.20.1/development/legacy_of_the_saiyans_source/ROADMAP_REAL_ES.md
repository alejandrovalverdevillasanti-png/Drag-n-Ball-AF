# Estado real de la versión fuente 0.3.0

## Incluido
- Base Forge 1.20.1 / 47.2.0 / Java 17.
- Registro de daño y Zenkai al morir.
- Copia de datos de Zenkai al clonar al jugador tras morir.
- Bonificación moderada de ataque al reaparecer.
- Helpers server-side para Break Limit y potencial legendario.
- Catálogos JSON iniciales de razas y transformaciones.
- Workflow de GitHub Actions para compilar.

## Pendiente
- Dimensión/Otro Mundo y reaparición especial.
- UI y selección/azar de razas y potencial.
- Entrada de tecla y paquetes de red para Break Limit.
- Sistema completo de Ki, técnicas y atributos.
- Transformaciones funcionales, modelos 3D, texturas y animaciones.
- NPC, enemigos, jefes, IA y combate aéreo.
- Misiones, torneos, maestros, planetas y generación del mundo.
- Música, voces y efectos.
- Pruebas reales de cliente Forge y Zalith.

Zalith es objetivo de compatibilidad, no compatibilidad verificada.
