package com.legacyofthesaiyans.progression;

/**
 * Initial progression data model.
 * Persistence, networking and gameplay hooks are implemented in later milestones.
 */
public final class ProgressionData {
    private double permanentZenkaiPower;
    private double potential;
    private int breakLimitLevel;

    public double getPermanentZenkaiPower() {
        return permanentZenkaiPower;
    }

    public void addPermanentZenkaiPower(double amount) {
        if (Double.isFinite(amount) && amount > 0.0D) {
            permanentZenkaiPower += amount;
        }
    }

    public double getPotential() {
        return potential;
    }

    public void addPotential(double amount) {
        if (Double.isFinite(amount) && amount > 0.0D) {
            potential += amount;
        }
    }

    public int getBreakLimitLevel() {
        return breakLimitLevel;
    }

    public void setBreakLimitLevel(int level) {
        breakLimitLevel = Math.max(0, Math.min(4, level));
    }
}
