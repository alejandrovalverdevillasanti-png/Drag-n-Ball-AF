# DRAGON BALL AF – LEGACY OF THE SAIYANS
## Proyecto inicial de desarrollo

**Objetivo:** Minecraft Java 1.20.1, Forge 47.2.0, Java 17. Compatible como objetivo con Zalith Launcher.

### Estado real de esta entrega
Este ZIP contiene el esqueleto inicial del proyecto Forge:
- configuración del mod;
- clase principal;
- modelo inicial de datos de progresión para Zenkai permanente, potencial y Break Limit;
- metadatos y configuración Gradle.

**Todavía no es un mod jugable ni un JAR compilado.** No incluye todavía modelos 3D, personajes, transformaciones funcionales, combate, música ni guardado persistente del Zenkai. Esos sistemas se implementarán por etapas y se probarán antes de llamarlos terminados.

### Cómo compilar
1. Instala un JDK 17.
2. Abre esta carpeta con IntelliJ IDEA o ejecuta `gradlew genIntellijRuns` / `gradlew build` después de añadir el Gradle Wrapper.
3. Gradle descargará ForgeGradle y Forge desde sus repositorios.
4. El JAR, si compila correctamente, aparecerá en `build/libs/`.

### Próximos hitos
1. Guardado persistente y sincronización de progresión (incluido Zenkai tras muerte/Otro Mundo).
2. Razas, creación de personaje y potencial legendario.
3. Ki, carga y minijuego Break Limit.
4. Registro de transformaciones y técnicas.
5. Entidades, modelos 3D y animaciones.
6. Mundo, misiones, torneos, música y optimización móvil.

### Nota de diseño
Dragon Ball AF y varias formas como SSJ10 son material fanmade y no tienen una continuidad oficial única. El proyecto distinguirá formas oficiales, variantes de fanmanga y formas originales del mod.


## Novedades de la versión 0.2.0
- Primera implementación del registro de daño recibido.
- Otorga un pequeño Zenkai permanente al morir.
- Copia los datos de Zenkai al jugador clonado tras la muerte.
- Reaplica una bonificación moderada de daño de ataque al reaparecer.
- El valor acumulado se guarda en los datos persistentes del jugador.

### Limitaciones conocidas
- El Otro Mundo todavía no está implementado como dimensión.
- El Zenkai aún no tiene interfaz, sincronización visual ni pantalla de historial.
- Break Limit todavía no tiene minijuego de pulsaciones ni transformaciones conectadas.
- Esta entrega sigue siendo código fuente y no un JAR probado.
- El proyecto no incluye aún los modelos 3D, personajes, técnicas, música ni las transformaciones completas.
